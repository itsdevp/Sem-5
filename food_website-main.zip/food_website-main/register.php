
<?php include 'function.php';

headers();
sign_up();
footers();
?>