<?php 
    
    include "conf.php";
    
                    echo $product_id = $_POST["Product_id"];
                   
                

?>