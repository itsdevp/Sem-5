<?php include 'function.php';

headers();
sign_in();

footers();
?>