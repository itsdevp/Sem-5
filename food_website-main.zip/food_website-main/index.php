<?php 
include 'function.php';
headers();
banners();
search_result();
loadtabel();
dishes();
msgModals();
introduction();
special_menu();
review();
order_contact();
footers();
