<?php include "function.php"; 
ad_headers(); 

ad_head_content();
search_modal();
charts_circle();
cards();
msgModals();
tables();
formModals();
ad_footers();?>
<script src="../"></script>