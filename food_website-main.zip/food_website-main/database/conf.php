<?php 

$server = "localhost";
$username = "root";
$password = "";
$database = "epiz_32582462_food_website";


$conn = mysqli_connect($server , $username ,$password ,$database) or die("<script>alert('connection failed ')</script>");

    
?>
